package com.springcore.CoreSpring;



public class India {
	public void Emp() {
		System.out.println("Modi is the prime minister of India");
	}

}
