package com.springcore.CoreSpring;


public class Welcome {
	public void show() {
		
		System.out.print("Welcome to Core Spring");
	}

}
