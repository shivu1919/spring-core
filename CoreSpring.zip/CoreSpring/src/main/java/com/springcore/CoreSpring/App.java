package com.springcore.CoreSpring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	
    	ConfigurableApplicationContext con = new ClassPathXmlApplicationContext("spring.xml"); 
    	
    	Welcome obj = con.getBean(Welcome.class);
    	
    	India obj2 =(India) con.getBean("ind");
    	
    	obj.show();
    	
    	obj2.Emp();
    
    }
}
