package com.newer.SpringCoreDemo;

public class Laptop {
	
	private int id;
	
	public Laptop(){
		System.out.print("I am a constructor");
	}
	
	public Laptop(int id) {
		this.id=id;
	}

}
