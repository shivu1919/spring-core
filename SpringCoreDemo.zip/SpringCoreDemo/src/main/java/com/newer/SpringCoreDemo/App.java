package com.newer.SpringCoreDemo;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       ConfigurableApplicationContext con = new ClassPathXmlApplicationContext("spring.xml");       
       
       Laptop lap = con.getBean(Laptop.class);
       
       System.out.print(lap);
       
       
    }
}
