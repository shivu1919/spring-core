package com.newer.SpringCoreDemo;


public class Human {
	
	private String name;
	private String add;
	
	
	
	
	
	public String getAdd() {
		return add;
	}



	public void setAdd(String add) {
		this.add = add;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public void hum() {
		System.out.println("I am a human");
	}

}
