package com.newer.SpringCoreDemo;

public class Alien {
	
	private int id;
	private Human human;
	
	

	public Human getHuman() {
		return human;
	}


	public void setHuman(Human human) {
		this.human = human;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	
	
	public void alien(int num) {
		
		System.out.println("Object created");
	}

}
